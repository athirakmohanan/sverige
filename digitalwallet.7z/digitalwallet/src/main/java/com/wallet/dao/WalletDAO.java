package com.wallet.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.wallet.entity.ProfileDetails;
import com.wallet.entity.TransactionDetails;
import com.wallet.entity.WalletDetails;
import com.wallet.entity.WalletHistory;
import com.wallet.service.NegativeBalanceException;

@Repository
public class WalletDAO {
	
	private List<WalletDetails> walletDetailList;
	
	WalletDAO(){
		walletDetailList=new ArrayList<>();
		WalletDetails walletUser1=new WalletDetails();
		walletUser1.setId(1);
		walletUser1.setAvailableBalance(0.0);
		
		ProfileDetails profileDetails=new ProfileDetails();
		profileDetails.setFirstName("Richard");
		profileDetails.setSurname("Daniel");
		profileDetails.setUsername("rida");
		profileDetails.setPassword("gol");
		profileDetails.setUniqueId("WALLET001");
		walletUser1.setProfileDetails(profileDetails);
		walletDetailList.add(walletUser1);
		
		WalletDetails walletUser2=new WalletDetails();
		walletUser2.setId(2);
		walletUser2.setAvailableBalance(0.0);
		
		ProfileDetails profileDetail=new ProfileDetails();
		profileDetail.setFirstName("Mitchel");
		profileDetail.setSurname("Clark");
		profileDetail.setUsername("micl");
		profileDetail.setPassword("gol");
		profileDetail.setUniqueId("WALLET002");
		walletUser2.setProfileDetails(profileDetail);
		walletDetailList.add(walletUser2);	
		
		
	}
	public boolean creditBalance(TransactionDetails transactionDetails) {
		double newBalance=0.0;
		boolean isCredited=false;
		for(WalletDetails walletDetails: walletDetailList) {
			if(transactionDetails.getWalletuser().equals(walletDetails.getProfileDetails().getUniqueId())) {
				WalletHistory walletHistory=new WalletHistory();
				
				newBalance=walletDetails.getAvailableBalance();
				walletHistory.setPrevBalance(newBalance);
				
				newBalance+=Double.parseDouble(transactionDetails.getChangevalue());
				walletDetails.setAvailableBalance(newBalance);
				
				walletHistory.setInputBalance(Double.parseDouble(transactionDetails.getChangevalue()));
				walletHistory.setNewBalance(newBalance);
				walletHistory.setUpdatedBy(transactionDetails.getExternalcaller());
				if(walletDetails.getWalletHistorylist()==null) {
					walletDetails.setWalletHistorylist(new ArrayList<>());
				}
				walletDetails.getWalletHistorylist().add(walletHistory);				
				
				isCredited=true;
			}
		}
		return isCredited;
	}
	
	public boolean debitBalance(TransactionDetails transactionDetails) throws NegativeBalanceException {
		double debitvalue=Double.parseDouble(transactionDetails.getChangevalue());
		double availableBalance=0.0;
		boolean isDebited=false;
		for(WalletDetails walletDetails: walletDetailList) {
			if(transactionDetails.getWalletuser().equals(walletDetails.getProfileDetails().getUniqueId())) {
				WalletHistory walletHistory=new WalletHistory();
				availableBalance=walletDetails.getAvailableBalance();
				walletHistory.setPrevBalance(availableBalance);
				if(availableBalance>=debitvalue) {
					availableBalance-=debitvalue;
					walletDetails.setAvailableBalance(availableBalance);
					
					walletHistory.setInputBalance(Double.parseDouble(transactionDetails.getChangevalue()));
					walletHistory.setNewBalance(availableBalance);
					walletHistory.setUpdatedBy(transactionDetails.getExternalcaller());
					walletDetails.getWalletHistorylist().add(walletHistory);
					
					isDebited=true;
				}				
				else				
				 throw new NegativeBalanceException("Debit action failed - Insufficient Balance");			
			}
		}
		return isDebited;
	}
	public List<WalletDetails> getWalletDetailList() {
		return walletDetailList;
	}
	public void setWalletDetailList(List<WalletDetails> walletDetailList) {
		this.walletDetailList = walletDetailList;
	}
	
}

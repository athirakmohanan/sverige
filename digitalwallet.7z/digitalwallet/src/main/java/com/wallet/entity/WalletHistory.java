package com.wallet.entity;

public class WalletHistory {
	private int id;
	private double inputBalance;
	private double prevBalance;
	private double newBalance;
	private String updatedBy;

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getInputBalance() {
		return inputBalance;
	}
	public void setInputBalance(double inputBalance) {
		this.inputBalance = inputBalance;
	}
	public double getPrevBalance() {
		return prevBalance;
	}
	public void setPrevBalance(double prevBalance) {
		this.prevBalance = prevBalance;
	}
	public double getNewBalance() {
		return newBalance;
	}
	public void setNewBalance(double newBalance) {
		this.newBalance = newBalance;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	
}

package com.wallet.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class TransactionDetails {
	
	@JsonInclude(Include.NON_EMPTY)
	private String externalcaller;
	
	@JsonInclude(Include.NON_EMPTY)
	private String walletuser;
	
	@JsonInclude(Include.NON_EMPTY)
	private String walletusermobile;
	
	@JsonInclude(Include.NON_EMPTY)
	private String transactiontype;
	
	@JsonInclude(Include.NON_EMPTY)
	private String changevalue;
	
	public String getExternalcaller() {
		return externalcaller;
	}
	public void setExternalcaller(String externalcaller) {
		this.externalcaller = externalcaller;
	}
	public String getWalletuser() {
		return walletuser;
	}
	public void setWalletuser(String walletuser) {
		this.walletuser = walletuser;
	}
	public String getWalletusermobile() {
		return walletusermobile;
	}
	public void setWalletusermobile(String walletusermobile) {
		this.walletusermobile = walletusermobile;
	}
	public String getTransactiontype() {
		return transactiontype;
	}
	public void setTransactiontype(String transactiontype) {
		this.transactiontype = transactiontype;
	}
	public String getChangevalue() {
		return changevalue;
	}
	public void setChangevalue(String changevalue) {
		this.changevalue = changevalue;
	}
	
	
}

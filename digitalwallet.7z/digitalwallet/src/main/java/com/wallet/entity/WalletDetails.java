package com.wallet.entity;

import java.util.List;

public class WalletDetails {
	private int id;
	private double availableBalance;
	private ProfileDetails profileDetails;
	private List<WalletHistory> walletHistorylist;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getAvailableBalance() {
		return availableBalance;
	}
	public void setAvailableBalance(double availableBalance) {
		this.availableBalance = availableBalance;
	}
	public ProfileDetails getProfileDetails() {
		return profileDetails;
	}
	public void setProfileDetails(ProfileDetails profileDetails) {
		this.profileDetails = profileDetails;
	}
	public List<WalletHistory> getWalletHistorylist() {
		return walletHistorylist;
	}
	public void setWalletHistorylist(List<WalletHistory> walletHistorylist) {
		this.walletHistorylist = walletHistorylist;
	}
	
	
	
}

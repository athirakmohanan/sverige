package com.wallet.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import com.wallet.entity.ErrorJSON;

@ControllerAdvice
public class ExceptionControllerAdvice {
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorJSON> exceptionHandler(Exception ex) {
		ErrorJSON errorJson = new ErrorJSON();
		errorJson.setErrorMsg(ex.getMessage());
		errorJson.setErrorCode(HttpStatus.PRECONDITION_FAILED.value());
		return new ResponseEntity<ErrorJSON>(errorJson, HttpStatus.OK);
	}

}

package com.wallet.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.wallet.entity.TransactionDetails;
import com.wallet.entity.WalletDetails;
import com.wallet.service.WalletService;
import com.wallet.service.NegativeBalanceException;
import com.wallet.service.UserNotFoundException;

@RestController
@RequestMapping("/digitalwallet")
public class WalletController {
	
	@Autowired
	private WalletService digitalWalletService;
	
	@PutMapping("/debitaction")
	public ResponseEntity<WalletDetails> performDebitAction(@RequestBody TransactionDetails transactionDetails) throws NegativeBalanceException {
		
		WalletDetails walletDetails;
		walletDetails = digitalWalletService.performDebitAction(transactionDetails);
		return new ResponseEntity<>(walletDetails,HttpStatus.OK);	
	}
	
	
	@PutMapping("/creditaction")
	public ResponseEntity<Void> performCreditAction(@RequestBody TransactionDetails transactionDetails) {
		
		boolean isCredited=digitalWalletService.performCreditAction(transactionDetails);
		if(isCredited)
			return new ResponseEntity<>(HttpStatus.OK);
		else
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}
	
	@GetMapping("/{userid}")
	public ResponseEntity<WalletDetails> getWalletBalance(@PathVariable("userid") String userId) throws UserNotFoundException {
		WalletDetails userWalletDetail=digitalWalletService.getWalletBalance(userId);
		return new ResponseEntity<WalletDetails>(userWalletDetail,HttpStatus.OK);
	}
	
}

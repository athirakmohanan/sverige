package com.wallet.service;

public class NegativeBalanceException extends Exception{
	/**
	 * @author athira
	 */
	private static final long serialVersionUID = 1L;
	
	private String errorMessage;
	
	public NegativeBalanceException(String errorMsg){
		super(errorMsg);
		this.errorMessage=errorMsg;
	}

	public String getErrorMessage() {
		return errorMessage;
	}	
	
}

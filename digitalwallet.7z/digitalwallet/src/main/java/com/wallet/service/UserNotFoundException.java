package com.wallet.service;

public class UserNotFoundException extends Exception{
	
	private String errorMessage;
	
	public UserNotFoundException(String errorMsg){
		super(errorMsg);
		this.errorMessage=errorMsg;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	
}

package com.wallet.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wallet.dao.WalletDAO;
import com.wallet.entity.TransactionDetails;
import com.wallet.entity.WalletDetails;

@Service
public class WalletService {
	
	@Autowired
	private WalletDAO walletDAO;
	
	public WalletDetails performDebitAction(TransactionDetails transactionDetails) throws NegativeBalanceException {
		WalletDetails walletDetail=null;
		boolean isDebited=walletDAO.debitBalance(transactionDetails);
		if(isDebited) {
			for(WalletDetails walletDetails: walletDAO.getWalletDetailList()) {
				if(transactionDetails.getWalletuser().equals(walletDetails.getProfileDetails().getUniqueId())) {
					walletDetail= walletDetails;
				}
			}
		}
		return walletDetail;
		
	}
	
	public boolean performCreditAction(TransactionDetails transactionDetails) {
		return walletDAO.creditBalance(transactionDetails);
	}
	
	public WalletDetails getWalletBalance(String userId) throws UserNotFoundException {
		WalletDetails userWalletDetail=null;
		for(WalletDetails walletDetails: walletDAO.getWalletDetailList()) {
			if(userId.equals(walletDetails.getProfileDetails().getUniqueId())) {
				userWalletDetail= walletDetails;
			}
		}
		if(userWalletDetail==null)
			throw new UserNotFoundException("User does not exist!!!");
		return userWalletDetail;
	}

}
